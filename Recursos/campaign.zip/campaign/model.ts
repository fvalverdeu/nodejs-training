export interface Campaign {
  id: number
  code: string
  shortName: string
  startDate: string
  endDate: string
}
