import Router from 'koa-router'

import Controller from './controller'
import schemaValidator from '../../../utils/schema-validator'
import schema from './schema'

const controller = new Controller()
const router = new Router({ prefix: '/campaign' })
const validator = schemaValidator({ params: schema })

router.get(
  'campaign/findByRegionAndZone',
  '/:iso',
  validator,
  controller.findByRegionAndZone
)

export default router
