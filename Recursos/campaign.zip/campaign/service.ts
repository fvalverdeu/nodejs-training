import axios from 'axios'
import { Campaign } from './model'

export default class {
  async search(
    country: string,
    region: string,
    zone: string
  ): Promise<Campaign> {
    const { data } = await axios.get(
      `https://api-qa.belcorp.biz/campaigns/${country}?region=${region}&zone=${zone}`,
      {
        headers: {
          'x-access-token':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MywidXNyIjoiYXBwUE9DIiwiaWF0IjoxNTY1MTkyNDc4LCJleHAiOjE1NjUyNzg4Nzh9.OMXvFP8gwe_wkQrptui9WcZHN91hH2V7HG4LSl4cHcM',
        },
      }
    )

    const { id, campaign_code, short_name, start_date, end_date } = data

    return {
      id,
      code: campaign_code,
      shortName: short_name,
      startDate: start_date,
      endDate: end_date,
    }
  }
}
