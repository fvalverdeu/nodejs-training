import country from "./modules/country/country.router";
import pokemon from "./modules/pokemon/pokemon.router";

export default [country, pokemon];