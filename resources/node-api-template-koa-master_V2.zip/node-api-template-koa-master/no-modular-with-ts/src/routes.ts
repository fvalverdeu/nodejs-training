import country from './routes/country.route'
import pokemon from './routes/pokemon.route'

export default [country, pokemon]
