import country from './modules/country/api'
import pokemon from './modules/pokemon/api'

export default [country, pokemon]
