import Joi from '@hapi/joi'

export default {
  id: Joi.number().required(),
}
