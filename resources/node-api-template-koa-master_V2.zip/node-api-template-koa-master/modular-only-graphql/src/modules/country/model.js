export default class {
  // eslint-disable-next-line camelcase
  constructor(name, iso, brand_id, currency, status) {
    this.name = name
    this.iso = iso
    // eslint-disable-next-line camelcase
    this.brand_id = brand_id
    this.currency = currency
    this.status = status
  }
}
