export interface Country {
  name: string
  iso: string
  brand_id: number
  currency: string
  status: boolean
}
